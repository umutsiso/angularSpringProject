CREATE VIEW [dbo].[case_supply_data] AS
    SELECT
        c.case_id,
        c.case_number,
        pr.provider_id,
        c.procedure_group_id,
        c.cpt_code,
        pr.name                                  AS           facility_name,
        p.product_skey,
        psc.primary_supply_category_code,
        psc.primary_supply_category_description,
        ssc.secondary_supply_category_code,
        ssc.secondary_supply_category_description,
        tsc.tertiary_supply_category_code,
        tsc.tertiary_supply_category_description,
        ps.item_description,
        ps.vendor_ctlg_number,
        ps.vendor_name,
        CASE WHEN pr.is_savings_actualyzer=1 THEN cs.pci ELSE NULL END AS pci,
        cs.price,
        cs.case_supply_id,
        cs.quantity,
        ph.physician_id,
        ph.code                                  AS           physician_code,
        ph.first_name                            AS           physician_first_name,
        ph.last_name                             AS           physician_last_name,
        ISNULL((SELECT COUNT(DISTINCT procedure_id)
                FROM procedures p
                WHERE p.case_id = c.case_id), 0) AS           child_count,
        (SELECT TOP 1 case_type
         FROM procedures
         WHERE case_id = c.case_id AND primary_procedure = 1) case_type,
        c.service_line_id,
        c.sub_service_line_id,
        c.date_of_service,
        c.patient_age_at_service,
        c.patient_type,
        (cs.price * cs.quantity)                 AS           total_supply_cost,
        (SELECT p.bed_count
         FROM providers p
         WHERE p.provider_id = c.provider_id)    AS           provider_bed_count,
        pr.region                                AS           provider_region,
        CASE WHEN pr.is_teaching=1 THEN 'TEACHING' ELSE 'NON_TEACHING' END AS facility_type
    FROM cases c
        JOIN case_supplies cs ON cs.case_id = c.case_id
        JOIN provider_supplies ps ON ps.provider_supply_id = cs.provider_supply_id
        JOIN products p ON p.product_skey = ps.product_skey
        JOIN primary_supply_category psc ON psc.primary_supply_category_code = p.primary_supply_category_code
        JOIN secondary_supply_category ssc ON ssc.secondary_supply_category_code = p.secondary_supply_category_code
        JOIN tertiary_supply_category tsc ON tsc.tertiary_supply_category_code = p.tertiary_supply_category_code
        JOIN physicians ph ON ph.physician_id = c.physician_id
        JOIN providers pr ON pr.provider_id = c.provider_id
    GROUP BY c.case_id,
        c.case_number,
        pr.provider_id,
        c.procedure_group_id,
        c.cpt_code,
        pr.name,
        p.product_skey,
        psc.primary_supply_category_code,
        psc.primary_supply_category_description,
        ssc.secondary_supply_category_code,
        ssc.secondary_supply_category_description,
        tsc.tertiary_supply_category_code,
        tsc.tertiary_supply_category_description,
        ps.item_description,
        ps.vendor_ctlg_number,
        ps.vendor_name,
        cs.pci,
        cs.price,
        cs.quantity,
        cs.case_supply_id,
        ph.physician_id,
        ph.code,
        ph.first_name,
        ph.last_name,
        c.service_line_id,
        c.sub_service_line_id,
        c.date_of_service,
        c.patient_age_at_service,
        c.patient_type,
        c.provider_id,
        pr.bed_count,
        pr.region,
        pr.is_savings_actualyzer,
        pr.is_teaching

GO

