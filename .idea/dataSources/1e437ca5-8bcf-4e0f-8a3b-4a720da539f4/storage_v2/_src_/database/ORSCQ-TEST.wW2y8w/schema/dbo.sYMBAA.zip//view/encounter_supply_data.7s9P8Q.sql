CREATE VIEW encounter_supply_data AS
  SELECT
    e.encounter_id,
    e.encounter_sub_service_line_id AS sub_service_line_id,
    e.base_msdrg_id,
    e.msdrg_id,
    e.primary_icd10_id AS icd10_code,
    e.discharge_date AS date_of_service,
    e.patient_age_at_service,
    e.patient_type,
    e.patient_account_number,
    e.readmission,
    e.complication,
    e.los,
    e.encounter_service_line_id AS service_line_id,
    r.expected_los,
    r.risk_type_code,
    pr.provider_id,
    pr.name AS facility_name,
    pr.region AS provider_region,
    CASE WHEN pr.is_teaching = 1 THEN 'TEACHING' ELSE 'NON_TEACHING' END AS facility_type,
    ep.physician_id,
    ep.code AS physician_code,
    ep.first_name AS physician_first_name,
    ep.last_name AS physician_last_name,
    (SELECT SUM(bed_count) FROM dbo.providers WHERE provider_id = e.provider_id) AS provider_bed_count,
    (SELECT COUNT(case_id) FROM dbo.cases WHERE encounter_id = e.encounter_id) AS child_count,
    CASE WHEN pr.is_savings_actualyzer = 1 THEN cs.pci ELSE NULL END AS pci,
    cs.price * cs.quantity AS total_supply_cost,
    cs.price, cs.case_supply_id, cs.quantity,
    ps.item_description,
    ps.vendor_ctlg_number,
    ps.vendor_name,
    p.product_skey,
    psc.primary_supply_category_code,
    psc.primary_supply_category_description,
    ssc.secondary_supply_category_code,
    ssc.secondary_supply_category_description,
    tsc.tertiary_supply_category_code,
    tsc.tertiary_supply_category_description
  FROM encounters e, dbo.encounter_risks AS r, dbo.encounter_physicians AS ep, dbo.providers AS pr,
    dbo.cases AS c, dbo.case_supplies AS cs, dbo.provider_supplies AS ps, dbo.products AS p,
    dbo.primary_supply_category AS psc,dbo. secondary_supply_category AS ssc,
    dbo.tertiary_supply_category AS tsc
  WHERE r.encounter_id = e.encounter_id
        AND pr.provider_id = e.provider_id
        AND ep.physician_id = e.physician_id
        AND c.encounter_id = e.encounter_id
        AND cs.case_id = c.case_id
        AND ps.provider_supply_id = cs.provider_supply_id
        AND ps.product_skey = p.product_skey
        AND p.primary_supply_category_code = psc.primary_supply_category_code
        AND p.secondary_supply_category_code = ssc.secondary_supply_category_code
        AND p.tertiary_supply_category_code = tsc.tertiary_supply_category_code
GO

