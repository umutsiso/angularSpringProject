CREATE VIEW encounter_data AS
    SELECT
        e.encounter_id,
        r.risk_type_code,
        e.encounter_service_line_id service_line_id,
        sl.description service_line_description,
        e.encounter_sub_service_line_id sub_service_line_id,
        ssl.description sub_service_line_description,
        e.base_msdrg_id,
        base.description base_msdrg_description,
        e.msdrg_id,
        msdrg.description msdrg_description,
        e.primary_icd10_id icd10_code,
        icd.description icd10_description,
        e.total_supply_cost,
        e.discharge_date date_of_service,
        e.patient_age_at_service,
        e.patient_type,
        e.patient_account_number,
        e.medical_record_number,
        e.patient_gender,
        e.complication,
        e.readmission,
        e.los,
        e.physician_id,
        phy.code physician_code,
        phy.first_name physician_first_name,
        phy.last_name physician_last_name,
        phy.specialty physician_specialty,
        e.provider_id,
        p.name facility_name,
        p.region provider_region,
        p.bed_count provider_bed_count,
        CASE WHEN p.is_teaching=1 THEN 'TEACHING' ELSE 'NON_TEACHING' END AS facility_type,
        r.expected_los,
        e.admission_date,
        (SELECT count(case_id) FROM cases WHERE encounter_id = e.encounter_id) child_count,
        (SELECT sum(room_time) FROM cases WHERE encounter_id = e.encounter_id) total_room_time,
        (SELECT sum(surgical_time) FROM cases WHERE encounter_id = e.encounter_id) total_surgical_time
    FROM encounters e
        JOIN encounter_risks r ON e.encounter_id = r.encounter_id
        JOIN service_lines sl ON e.encounter_service_line_id = sl.service_line_id
        JOIN sub_service_lines ssl ON e.encounter_sub_service_line_id = ssl.sub_service_line_id
        JOIN base_msdrgs base ON e.base_msdrg_id = base.base_msdrg_id
        LEFT JOIN msdrgs msdrg ON e.msdrg_id = msdrg.msdrg_id
        LEFT JOIN icd10s icd ON e.primary_icd10_id = icd.icd10_id
        LEFT JOIN providers p ON e.provider_id = p.provider_id
        LEFT JOIN encounter_physicians phy ON e.physician_id = phy.physician_id;

GO

