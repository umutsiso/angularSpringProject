CREATE VIEW case_data AS
    SELECT
        c.case_id,
        c.case_number,
        c.service_line_id,
        sl.description service_line_description,
        c.sub_service_line_id,
        ssl.description sub_service_line_description,
        c.procedure_group_id,
        pxg.description procedure_group_description,
        c.cpt_code,
        cpts.description cpt_description,
        c.total_supply_cost,
        c.date_of_service,
        c.patient_age_at_service,
        c.patient_type,
        c.room_time,
        c.surgical_time,
        c.physician_id,
        c.encounter_id,
        phy.code physician_code,
        phy.first_name physician_first_name,
        phy.last_name physician_last_name,
        p.provider_id,
        p.name facility_name,
        p.bed_count provider_bed_count,
        p.region provider_region,
        CASE WHEN p.is_teaching=1 THEN 'TEACHING' ELSE 'NON_TEACHING' END AS facility_type,
        (SELECT count(procedure_id) FROM procedures WHERE case_id = c.case_id) child_count,
        (SELECT top 1 case_type FROM procedures WHERE case_id = c.case_id AND primary_procedure = 1) case_type
    FROM cases c
        LEFT JOIN providers p ON c.provider_id = p.provider_id
        JOIN service_lines sl ON c.service_line_id = sl.service_line_id
        JOIN sub_service_lines ssl ON c.sub_service_line_id = ssl.sub_service_line_id
        JOIN procedure_groups pxg ON c.procedure_group_id = pxg.procedure_group_id
        LEFT JOIN cpts ON c.cpt_code = cpts.cpt_code
        LEFT JOIN physicians phy ON c.physician_id = phy.physician_id

GO

